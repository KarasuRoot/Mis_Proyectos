** RENAME CHALLENGE.TXT TO CHALLENGE.EXE **

The challenge features multiple levels of increasing difficulty.
The goal is to solve as many levels as possible.

For the challenge to be considered valid, the applicant must submit the solution for each completed level in PDF format, detailing the process used to reach the solution.

After the submission deadline has passed, all received solutions will be evaluated. The best submissions will be selected for admission to the courses, until all available spots are filled.

Solutions should be sent to the following email address: academy@binarygecko.com

